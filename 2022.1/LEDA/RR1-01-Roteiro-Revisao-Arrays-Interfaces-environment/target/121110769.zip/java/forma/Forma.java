package forma;

/**
 * @author Jônatas Tavares dos Santos - 121110769
 */
public interface Forma {

    public double calculaArea();
}
