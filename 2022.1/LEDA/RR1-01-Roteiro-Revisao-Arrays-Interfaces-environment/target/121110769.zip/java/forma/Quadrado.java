package forma;

/**
 * @author Jônatas Tavares dos Santos - 121110769
 */
public class Quadrado extends Retangulo {

    public Quadrado(double lado) {
        super(lado, lado);
    }
}
